package com.example.pojo;

public class Dish {
    public String name;
    public float pricce;
}
