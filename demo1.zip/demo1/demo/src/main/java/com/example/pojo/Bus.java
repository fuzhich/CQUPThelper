package com.example.pojo;

import java.net.URL;

public class Bus {
    public int number;
    public URL picUrl;
}
