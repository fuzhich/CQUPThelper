package com.example.pojo;

public class User {

  public int id;
  public String name;
  public String gender;
  public String institute;
  public String grade;

}
