package com.example.pojo;

import java.net.URL;

public class Window_1 {
    public String name;
    public int id;
    public URL picUrl;

    @Override
    public String toString() {
        return "Window_1{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", picUrl='" + picUrl + '\'' +
                '}';
    }
}
