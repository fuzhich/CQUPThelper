package com.example.pojo;

import java.time.LocalDateTime;
import java.util.Date;

public class Notice {
    public String msg;
    public LocalDateTime updateTime;
}
