package com.example.vo;

import com.example.pojo.Window_2;

import java.util.List;

public class Windowsresult {
    public int code;
    public class Result{
        public Window_2 data=new Window_2();
    }
    public Result result =new Result();
}
