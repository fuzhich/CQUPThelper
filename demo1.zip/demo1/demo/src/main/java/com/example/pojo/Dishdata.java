package com.example.pojo;

public class Dishdata {
    public String name;
    public float price;
    public int windowid;
}
