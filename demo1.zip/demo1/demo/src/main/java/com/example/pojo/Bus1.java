package com.example.pojo;

import java.net.URL;

public class Bus1 {
    public int number;
    public String picUrl;
}
