package com.example.pojo;

import java.util.List;

public class Window_2 {
    public String name;
    public List<Dish> dishes;


}
